/*
  Dichiarazione delle funzioni come prototipi
*/
void DefineCursor( void);
void do_grid( int i);
void read_pos( void);
void show_mark( int x, int y);
void do_snap( int x, int y);
void plot_mark( int l, int t);
int chk_xy( int x, int y);
void store_coord( int l, int t);
void show_field( void);
int make_extrude( void);
int make_spinline( void);
int read_point( void);
