Thanks to FTB for this excellent software.
https://macsbug.wordpress.com/2016/12/27/raytracing-with-esp32/ 